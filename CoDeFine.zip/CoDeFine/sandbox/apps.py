from django.apps import AppConfig


class SandboxConfig(AppConfig):
    name = 'sandbox'
